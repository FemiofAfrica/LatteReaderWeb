# Corresponding Source — eSpeak-NG WASM phonemizer (LatteReader Web)

This archive is the Corresponding Source for the WebAssembly phonemizer
component that LatteReader Web serves to browsers, offered under GNU GPLv3
section 6(d).

## Layout

    espeak-ng-4870adfa.../   pristine eSpeak-NG source at the pinned commit
    build/                   our build recipe, patches, toolchain pins, test harnesses
    notices/                 licence texts that must travel with the object code
    MODIFICATIONS            GPLv3 5(a)/5(b) modification notice
    PINS.txt                 pinned revisions, hashes, exact flags, tool versions
    SOURCE-MANIFEST.sha256   SHA-256 of every file in this archive

## Rebuilding

    bash build/build-espeak-ng-wasm.sh

Requires: git, curl, tar/xz, gcc, make, autoconf, automake, libtool,
pkg-config, node, python3. No login, subscription or private key is needed.
The script downloads the pinned emscripten release, checks its SHA-256,
extracts a pruned toolchain, clones eSpeak-NG at the pinned commit, applies the
patches, and runs upstream's own documented two-phase emscripten build.

## What is shipped as object code

    espeakng.worker.js    emscripten runtime + WebIDL glue (MIT runtime, GPLv3 eSpeak bindings)
    espeakng.worker.wasm  compiled eSpeak-NG (GPLv3)
    espeakng.worker.data  the espeak-ng-data the module mounts at /usr/share/espeak-ng-data (GPLv3)

Licence: GNU GPL version 3 or later. There is NO WARRANTY.
